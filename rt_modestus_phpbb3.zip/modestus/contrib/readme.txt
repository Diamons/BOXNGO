phpBB style name: modestus
Designed by: RocketTheme, LLC
http://www.rockettheme.com/phpbb3
     
     This is the readme.text file with short description of the phpBB3 style funcionality and configuration. Modestus is a modern and elegant style from RocketTheme.
     
     1. Installation
     
     Style is installed as the usual phpBB3 style but in order to work properly php support in templates MUST be enabled in the phpBB3 Administration Control Panel.
     For basic style installation instructions please refer to: http://www.phpbb.com/kb/article/how-to-install-styles-on-phpbb3/
     
     1.1 Enabling PHP support in templates.
     
     Please log in into your phpBB3 Administration Control Panel. Go to "General"  tab. Next, choose "Security settings" and set "Allow php in templates" to Yes.
     
     2. Style configuration
     
     phpBB3 style is configured as any other phpBB3 style, however we have made few little additions to the basic prosilver style. For example you can switch color variations on the fly, without switching or installing
     additional themes. All this configuration options can be found in the "modestus.php" file. Near the every option there is short comment explaining how current setting works.
     
     2.1 Other differences
     Logos are located /theme/images/stylex
     
     3. Additional files list:
     
     modestus.php - configuration file
     rokbb3.php - few useful functions (don't modify)
     rokbox/*.* - rokbox js files, enabling rokbox in modestus.php will allow you to display images, attachments in RokBox environment.
     
     4. Sources
     
     Sources are Adobe Fireworks slices, which you can easily modify and adjust it to your needs.
     
     5. More Information
     
     For more informations about RocketTheme phpBB3 styles please visit http://www.rockettheme.com/phpbb3
     
     6. FAQ
     
     I. I' changing color variations in modestus.php and changes are not reflected on the page, did i make something wrong ?
        No, probably you have been playin a little with preset changer in the main menu on the forum. It's based on cookies, so all you have to do is press "Reset Settings" at the bottom of the forum or clear the browser cookies.
    